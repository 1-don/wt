var myApp = angular
    .module("myModule", [])
    .controller("myController", function($scope) {
        var bill = { rate: "0", qty: "0", amount: "0" };
        $scope.bill = bill;

        $scope.calculate_bill = function(bill) {
            bill.amount = bill.rate * bill.qty;
        };
    });
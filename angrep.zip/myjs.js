var myApp = angular
    .module("myModule", [])
    .controller("myController", function ($scope) {
        var employee = [
            { firstName: "Ram", lastName: "Patil", city: ["Nashik","Pune","Mumbai"] },
            { firstName: "Akash", lastName: "Patil", city: ["Pune"] },
            { firstName: "Naresh", lastName: "Deore", city: ["Mumbai","Thane"] }
        ];
        $scope.employee = employee;
    });